export * from './partner.service';
import { PartnerService } from './partner.service';
export const APIS = [PartnerService];
