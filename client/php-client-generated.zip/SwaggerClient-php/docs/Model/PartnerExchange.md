# PartnerExchange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**\Swagger\Client\Model\ComponentsParametersAmount**](ComponentsParametersAmount.md) |  | [optional] 
**from** | [**\Swagger\Client\Model\ComponentsParametersFrom**](ComponentsParametersFrom.md) |  | [optional] 
**to** | [**\Swagger\Client\Model\ComponentsParametersTo**](ComponentsParametersTo.md) |  | [optional] 
**anonymous** | [**\Swagger\Client\Model\ComponentsParametersAnonymous**](ComponentsParametersAnonymous.md) |  | [optional] 
**ip** | [**\Swagger\Client\Model\ComponentsParametersIp**](ComponentsParametersIp.md) |  | [optional] 
**user_agent** | [**\Swagger\Client\Model\ComponentsParametersUserAgent**](ComponentsParametersUserAgent.md) |  | [optional] 
**timezone** | [**\Swagger\Client\Model\ComponentsParametersTimezone**](ComponentsParametersTimezone.md) |  | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

