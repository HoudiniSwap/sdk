# NetworkDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Network name | [optional] 
**short_name** | **string** | Network short name | [optional] 
**address_validation** | **string** | Network address validator, will return a value from https://github.com/christsim/multicoin-address-validator or regex | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

