# TokenDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** | Token ID | [optional] 
**name** | **string** | Token name | [optional] 
**network** | [**\Swagger\Client\Model\NetworkDTO**](NetworkDTO.md) |  | [optional] 
**symbol** | **string** | Token symbol | [optional] 
**color** | **string** | Hex color for the token | [optional] 
**keyword** | **string** | keywords for the token | [optional] 
**display_name** | **string** | Friendly display name | [optional] 
**icon** | **string** | Icon for the token | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

