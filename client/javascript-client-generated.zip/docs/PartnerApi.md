# HoudiniSwap.PartnerApi

All URIs are relative to *https://api-partner.houdiniswap.com/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**exchangePost**](PartnerApi.md#exchangePost) | **POST** /exchange | Create an exchange order             (partner.exchange)
[**quoteGet**](PartnerApi.md#quoteGet) | **GET** /quote | Performs a quote and returns the best price for the swap pair             (partner.quote)
[**statusGet**](PartnerApi.md#statusGet) | **GET** /status | Get the order status             (partner.status)
[**tokensGet**](PartnerApi.md#tokensGet) | **GET** /tokens | Get the list of available tokens for exchange             (partner.tokens)

<a name="exchangePost"></a>
# **exchangePost**
> InlineResponse200 exchangePost(body)

Create an exchange order             (partner.exchange)

### Example
```javascript
import {HoudiniSwap} from 'houdini_swap';
let defaultClient = HoudiniSwap.ApiClient.instance;

// Configure API key authorization: ApiKeyAuth
let ApiKeyAuth = defaultClient.authentications['ApiKeyAuth'];
ApiKeyAuth.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//ApiKeyAuth.apiKeyPrefix = 'Token';

let apiInstance = new HoudiniSwap.PartnerApi();
let body = new HoudiniSwap.PartnerExchange(); // PartnerExchange | Optional description in `partner.exchange` Schema

apiInstance.exchangePost(body, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PartnerExchange**](PartnerExchange.md)| Optional description in &#x60;partner.exchange&#x60; Schema | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quoteGet"></a>
# **quoteGet**
> QuoteDTO quoteGet(amount, from, to, anonymous)

Performs a quote and returns the best price for the swap pair             (partner.quote)

### Example
```javascript
import {HoudiniSwap} from 'houdini_swap';
let defaultClient = HoudiniSwap.ApiClient.instance;

// Configure API key authorization: ApiKeyAuth
let ApiKeyAuth = defaultClient.authentications['ApiKeyAuth'];
ApiKeyAuth.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//ApiKeyAuth.apiKeyPrefix = 'Token';

let apiInstance = new HoudiniSwap.PartnerApi();
let amount = "amount_example"; // String | The amount which the client is willing to transfer
let from = "from_example"; // String | The TokenID of a currency the client will transfer
let to = "to_example"; // String | The TokenID of a currency the client will receive
let anonymous = true; // Boolean | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route

apiInstance.quoteGet(amount, from, to, anonymous, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **String**| The amount which the client is willing to transfer | 
 **from** | **String**| The TokenID of a currency the client will transfer | 
 **to** | **String**| The TokenID of a currency the client will receive | 
 **anonymous** | **Boolean**| Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route | 

### Return type

[**QuoteDTO**](QuoteDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="statusGet"></a>
# **statusGet**
> InlineResponse200 statusGet(id)

Get the order status             (partner.status)

### Example
```javascript
import {HoudiniSwap} from 'houdini_swap';
let defaultClient = HoudiniSwap.ApiClient.instance;

// Configure API key authorization: ApiKeyAuth
let ApiKeyAuth = defaultClient.authentications['ApiKeyAuth'];
ApiKeyAuth.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//ApiKeyAuth.apiKeyPrefix = 'Token';

let apiInstance = new HoudiniSwap.PartnerApi();
let id = "id_example"; // String | Houdini Order ID

apiInstance.statusGet(id, (error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Houdini Order ID | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="tokensGet"></a>
# **tokensGet**
> [TokenDTO] tokensGet()

Get the list of available tokens for exchange             (partner.tokens)

### Example
```javascript
import {HoudiniSwap} from 'houdini_swap';
let defaultClient = HoudiniSwap.ApiClient.instance;

// Configure API key authorization: ApiKeyAuth
let ApiKeyAuth = defaultClient.authentications['ApiKeyAuth'];
ApiKeyAuth.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//ApiKeyAuth.apiKeyPrefix = 'Token';

let apiInstance = new HoudiniSwap.PartnerApi();
apiInstance.tokensGet((error, data, response) => {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
});
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**[TokenDTO]**](TokenDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

