# HoudiniSwap.QuoteDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountOut** | **Number** | Quoted amount out | [optional] 
**min** | **Number** | Minimal amount accepted for exchange | [optional] 
**max** | **Number** | Maximal amount accepted for exchange | [optional] 
