# HoudiniSwap.NetworkDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Network name | [optional] 
**shortName** | **String** | Network short name | [optional] 
**memoNeeded** | **Boolean** | Network requires a memo/extra id field | [optional] 
**addressValidation** | **String** | Network address validator, will return a value from https://github.com/christsim/multicoin-address-validator or regex | [optional] 
