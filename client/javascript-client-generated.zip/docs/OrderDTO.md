# HoudiniSwap.OrderDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**houdiniId** | **String** | Houdini ID | [optional] 
**created** | [**Date**](DateTime.md) | Order created at | [optional] 
**senderAddress** | **String** | Address (of the deposit) to which the transfer will have to be made | [optional] 
**receiverAddress** | **String** | Address where the client will receive payment | [optional] 
**anonymous** | **Boolean** | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route | [optional] 
**expires** | [**Date**](DateTime.md) | Deposit must be made before this date/time | [optional] 
**status** | **Number** | Order status:          NEW: -1,         WAITING: 0,         CONFIRMING: 1,         EXCHANGING: 2,         ANONYMIZING: 3,         FINISHED: 4,         EXPIRED: 5,         FAILED: 6,         REFUNDED: 7 | [optional] 
**inAmount** | **Number** | The amount that the client specified when creating the exchange | [optional] 
**inSymbol** | **String** | The TokenID of a currency the client will transfer | [optional] 
**outAmount** | **Number** | The amount that will be returned by the exchange to the specified receiverAddress | [optional] 
**outSymbol** | **String** | The TokenID of a currency the client will receive | [optional] 

<a name="StatusEnum"></a>
## Enum: StatusEnum

* `_1` (value: `-1`)
* `_0` (value: `0`)
* `_1_2` (value: `1`)
* `_2` (value: `2`)
* `_3` (value: `3`)
* `_4` (value: `4`)
* `_5` (value: `5`)
* `_6` (value: `6`)
* `_7` (value: `7`)


<a name="InSymbolEnum"></a>
## Enum: InSymbolEnum

* `POOF` (value: `"POOF"`)
* `BTC` (value: `"BTC"`)
* `ETH` (value: `"ETH"`)
* `BNB` (value: `"BNB"`)
* `USDT` (value: `"USDT"`)
* `BUSD` (value: `"BUSD"`)
* `USDC` (value: `"USDC"`)
* `DAI` (value: `"DAI"`)
* `SOL` (value: `"SOL"`)
* `MATIC` (value: `"MATIC"`)
* `ADA` (value: `"ADA"`)
* `XRP` (value: `"XRP"`)
* `XMR` (value: `"XMR"`)
* `USDTTRON` (value: `"USDTTRON"`)
* `USDTBSC` (value: `"USDTBSC"`)
* `DAIBSC` (value: `"DAIBSC"`)
* `AVAXC` (value: `"AVAXC"`)
* `CRO` (value: `"CRO"`)
* `BUSDETH` (value: `"BUSDETH"`)
* `DOGE` (value: `"DOGE"`)
* `ETHBSC` (value: `"ETHBSC"`)
* `ETHARB` (value: `"ETHARB"`)
* `USDTARB` (value: `"USDTARB"`)
* `BDX` (value: `"BDX"`)
* `FTM` (value: `"FTM"`)
* `LTC` (value: `"LTC"`)
* `FLOKI` (value: `"FLOKI"`)
* `SHIB` (value: `"SHIB"`)
* `LEASH` (value: `"LEASH"`)
* `BONE` (value: `"BONE"`)
* `KAVA` (value: `"KAVA"`)
* `APE` (value: `"APE"`)
* `BRISE` (value: `"BRISE"`)
* `LINK` (value: `"LINK"`)
* `ATOM` (value: `"ATOM"`)
* `ARB` (value: `"ARB"`)
* `APESWAP` (value: `"APESWAP"`)
* `SCRT` (value: `"SCRT"`)
* `FIRO` (value: `"FIRO"`)
* `FIROBSC` (value: `"FIROBSC"`)
* `KNC` (value: `"KNC"`)
* `KNCBSC` (value: `"KNCBSC"`)


<a name="OutSymbolEnum"></a>
## Enum: OutSymbolEnum

* `POOF` (value: `"POOF"`)
* `BTC` (value: `"BTC"`)
* `ETH` (value: `"ETH"`)
* `BNB` (value: `"BNB"`)
* `USDT` (value: `"USDT"`)
* `BUSD` (value: `"BUSD"`)
* `USDC` (value: `"USDC"`)
* `DAI` (value: `"DAI"`)
* `SOL` (value: `"SOL"`)
* `MATIC` (value: `"MATIC"`)
* `ADA` (value: `"ADA"`)
* `XRP` (value: `"XRP"`)
* `XMR` (value: `"XMR"`)
* `USDTTRON` (value: `"USDTTRON"`)
* `USDTBSC` (value: `"USDTBSC"`)
* `DAIBSC` (value: `"DAIBSC"`)
* `AVAXC` (value: `"AVAXC"`)
* `CRO` (value: `"CRO"`)
* `BUSDETH` (value: `"BUSDETH"`)
* `DOGE` (value: `"DOGE"`)
* `ETHBSC` (value: `"ETHBSC"`)
* `ETHARB` (value: `"ETHARB"`)
* `USDTARB` (value: `"USDTARB"`)
* `BDX` (value: `"BDX"`)
* `FTM` (value: `"FTM"`)
* `LTC` (value: `"LTC"`)
* `FLOKI` (value: `"FLOKI"`)
* `SHIB` (value: `"SHIB"`)
* `LEASH` (value: `"LEASH"`)
* `BONE` (value: `"BONE"`)
* `KAVA` (value: `"KAVA"`)
* `APE` (value: `"APE"`)
* `BRISE` (value: `"BRISE"`)
* `LINK` (value: `"LINK"`)
* `ATOM` (value: `"ATOM"`)
* `ARB` (value: `"ARB"`)
* `APESWAP` (value: `"APESWAP"`)
* `SCRT` (value: `"SCRT"`)
* `FIRO` (value: `"FIRO"`)
* `FIROBSC` (value: `"FIROBSC"`)
* `KNC` (value: `"KNC"`)
* `KNCBSC` (value: `"KNCBSC"`)

