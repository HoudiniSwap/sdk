# HoudiniSwap.InlineResponse500

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
