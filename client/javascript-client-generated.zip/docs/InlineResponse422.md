# HoudiniSwap.InlineResponse422

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
