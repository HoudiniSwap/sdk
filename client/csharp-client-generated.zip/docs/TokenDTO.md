# IO.Swagger.Model.TokenDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Token ID | [optional] 
**Name** | **string** | Token name | [optional] 
**Network** | [**NetworkDTO**](NetworkDTO.md) |  | [optional] 
**Symbol** | **string** | Token symbol | [optional] 
**Color** | **string** | Hex color for the token | [optional] 
**Keyword** | **string** | keywords for the token | [optional] 
**DisplayName** | **string** | Friendly display name | [optional] 
**Icon** | **string** | Icon for the token | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

