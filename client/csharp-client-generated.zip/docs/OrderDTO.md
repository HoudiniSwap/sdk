# IO.Swagger.Model.OrderDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HoudiniId** | **string** | Houdini ID | [optional] 
**Created** | [**DateTime**](DateTime.md) | Order created at | [optional] 
**SenderAddress** | **string** | Address (of the deposit) to which the transfer will have to be made | [optional] 
**ReceiverAddress** | **string** | Address where the client will receive payment | [optional] 
**SenderTag** | **string** | Deposit address tag/memo | [optional] 
**ReceiverTag** | **string** | Destination address tag/memo | [optional] 
**Anonymous** | **bool?** | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route | [optional] 
**Expires** | [**DateTime**](DateTime.md) | Deposit must be made before this date/time | [optional] 
**Status** | [**decimal?**](BigDecimal.md) | Order status:          NEW: -1,         WAITING: 0,         CONFIRMING: 1,         EXCHANGING: 2,         ANONYMIZING: 3,         FINISHED: 4,         EXPIRED: 5,         FAILED: 6,         REFUNDED: 7 | [optional] 
**InAmount** | [**decimal?**](BigDecimal.md) | The amount that the client specified when creating the exchange | [optional] 
**InSymbol** | **string** | The TokenID of a currency the client will transfer | [optional] 
**OutAmount** | [**decimal?**](BigDecimal.md) | The amount that will be returned by the exchange to the specified receiverAddress | [optional] 
**OutSymbol** | **string** | The TokenID of a currency the client will receive | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

