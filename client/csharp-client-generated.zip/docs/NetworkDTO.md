# IO.Swagger.Model.NetworkDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Network name | [optional] 
**ShortName** | **string** | Network short name | [optional] 
**MemoNeeded** | **bool?** | Network requires a memo/extra id field | [optional] 
**AddressValidation** | **string** | Network address validator, will return a value from https://github.com/christsim/multicoin-address-validator or regex | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

