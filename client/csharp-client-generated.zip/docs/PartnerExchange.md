# IO.Swagger.Model.PartnerExchange
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | [**Componentsparametersamount**](Componentsparametersamount.md) |  | [optional] 
**From** | [**Componentsparametersfrom**](Componentsparametersfrom.md) |  | [optional] 
**To** | [**Componentsparametersto**](Componentsparametersto.md) |  | [optional] 
**ReceiverTag** | [**ComponentsparametersreceiverTag**](ComponentsparametersreceiverTag.md) |  | [optional] 
**Anonymous** | [**Componentsparametersanonymous**](Componentsparametersanonymous.md) |  | [optional] 
**Ip** | [**Componentsparametersip**](Componentsparametersip.md) |  | [optional] 
**UserAgent** | [**ComponentsparametersuserAgent**](ComponentsparametersuserAgent.md) |  | [optional] 
**Timezone** | [**Componentsparameterstimezone**](Componentsparameterstimezone.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

