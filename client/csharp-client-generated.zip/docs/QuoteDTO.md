# IO.Swagger.Model.QuoteDTO
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AmountOut** | [**decimal?**](BigDecimal.md) | Quoted amount out | [optional] 
**Min** | [**decimal?**](BigDecimal.md) | Minimal amount accepted for exchange | [optional] 
**Max** | [**decimal?**](BigDecimal.md) | Maximal amount accepted for exchange | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

