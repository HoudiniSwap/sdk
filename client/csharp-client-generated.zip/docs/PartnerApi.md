# IO.Swagger.Api.PartnerApi

All URIs are relative to *https://api-partner.houdiniswap.com/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ExchangePost**](PartnerApi.md#exchangepost) | **POST** /exchange | Create an exchange order             (partner.exchange)
[**QuoteGet**](PartnerApi.md#quoteget) | **GET** /quote | Performs a quote and returns the best price for the swap pair             (partner.quote)
[**StatusGet**](PartnerApi.md#statusget) | **GET** /status | Get the order status             (partner.status)
[**TokensGet**](PartnerApi.md#tokensget) | **GET** /tokens | Get the list of available tokens for exchange             (partner.tokens)

<a name="exchangepost"></a>
# **ExchangePost**
> InlineResponse200 ExchangePost (PartnerExchange body)

Create an exchange order             (partner.exchange)

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class ExchangePostExample
    {
        public void main()
        {
            // Configure API key authorization: ApiKeyAuth
            Configuration.Default.AddApiKey("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("Authorization", "Bearer");

            var apiInstance = new PartnerApi();
            var body = new PartnerExchange(); // PartnerExchange | Optional description in `partner.exchange` Schema

            try
            {
                // Create an exchange order             (partner.exchange)
                InlineResponse200 result = apiInstance.ExchangePost(body);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PartnerApi.ExchangePost: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PartnerExchange**](PartnerExchange.md)| Optional description in &#x60;partner.exchange&#x60; Schema | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="quoteget"></a>
# **QuoteGet**
> QuoteDTO QuoteGet (string amount, string from, string to, bool? anonymous)

Performs a quote and returns the best price for the swap pair             (partner.quote)

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class QuoteGetExample
    {
        public void main()
        {
            // Configure API key authorization: ApiKeyAuth
            Configuration.Default.AddApiKey("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("Authorization", "Bearer");

            var apiInstance = new PartnerApi();
            var amount = amount_example;  // string | The amount which the client is willing to transfer
            var from = from_example;  // string | The TokenID of a currency the client will transfer
            var to = to_example;  // string | The TokenID of a currency the client will receive
            var anonymous = true;  // bool? | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route

            try
            {
                // Performs a quote and returns the best price for the swap pair             (partner.quote)
                QuoteDTO result = apiInstance.QuoteGet(amount, from, to, anonymous);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PartnerApi.QuoteGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **string**| The amount which the client is willing to transfer | 
 **from** | **string**| The TokenID of a currency the client will transfer | 
 **to** | **string**| The TokenID of a currency the client will receive | 
 **anonymous** | **bool?**| Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route | 

### Return type

[**QuoteDTO**](QuoteDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="statusget"></a>
# **StatusGet**
> InlineResponse200 StatusGet (string id)

Get the order status             (partner.status)

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class StatusGetExample
    {
        public void main()
        {
            // Configure API key authorization: ApiKeyAuth
            Configuration.Default.AddApiKey("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("Authorization", "Bearer");

            var apiInstance = new PartnerApi();
            var id = id_example;  // string | Houdini Order ID

            try
            {
                // Get the order status             (partner.status)
                InlineResponse200 result = apiInstance.StatusGet(id);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PartnerApi.StatusGet: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **string**| Houdini Order ID | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="tokensget"></a>
# **TokensGet**
> List<TokenDTO> TokensGet ()

Get the list of available tokens for exchange             (partner.tokens)

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class TokensGetExample
    {
        public void main()
        {
            // Configure API key authorization: ApiKeyAuth
            Configuration.Default.AddApiKey("Authorization", "YOUR_API_KEY");
            // Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
            // Configuration.Default.AddApiKeyPrefix("Authorization", "Bearer");

            var apiInstance = new PartnerApi();

            try
            {
                // Get the list of available tokens for exchange             (partner.tokens)
                List&lt;TokenDTO&gt; result = apiInstance.TokensGet();
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling PartnerApi.TokensGet: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<TokenDTO>**](TokenDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
