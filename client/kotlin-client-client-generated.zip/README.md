# io.swagger.client - Kotlin client library for HoudiniSwap

## Requires

* Kotlin 1.4.30
* Gradle 5.3

## Build

First, create the gradle wrapper script:

```
gradle wrapper
```

Then, run:

```
./gradlew check assemble
```

This runs all tests and packages the library.

## Features/Implementation Notes

* Supports JSON inputs/outputs, File inputs, and Form inputs.
* Supports collection formats for query parameters: csv, tsv, ssv, pipes.
* Some Kotlin and Java types are fully qualified to avoid conflicts with types defined in Swagger definitions.
* Implementation of ApiClient is intended to reduce method counts, specifically to benefit Android targets.

<a name="documentation-for-api-endpoints"></a>
## Documentation for API Endpoints

All URIs are relative to */*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*PartnerApi* | [**exchangePost**](docs/PartnerApi.md#exchangepost) | **POST** /exchange | Create an exchange order             (partner.exchange)
*PartnerApi* | [**quoteGet**](docs/PartnerApi.md#quoteget) | **GET** /quote | Performs a quote and returns the best price for the swap pair             (partner.quote)
*PartnerApi* | [**statusGet**](docs/PartnerApi.md#statusget) | **GET** /status | Get the order status             (partner.status)
*PartnerApi* | [**tokensGet**](docs/PartnerApi.md#tokensget) | **GET** /tokens | Get the list of available tokens for exchange             (partner.tokens)

<a name="documentation-for-models"></a>
## Documentation for Models

 - [io.swagger.client.models.InlineResponse200](docs/InlineResponse200.md)
 - [io.swagger.client.models.InlineResponse422](docs/InlineResponse422.md)
 - [io.swagger.client.models.InlineResponse4221](docs/InlineResponse4221.md)
 - [io.swagger.client.models.InlineResponse4222](docs/InlineResponse4222.md)
 - [io.swagger.client.models.InlineResponse4223](docs/InlineResponse4223.md)
 - [io.swagger.client.models.InlineResponse500](docs/InlineResponse500.md)
 - [io.swagger.client.models.NetworkDTO](docs/NetworkDTO.md)
 - [io.swagger.client.models.OrderDTO](docs/OrderDTO.md)
 - [io.swagger.client.models.Partnerexchange](docs/Partnerexchange.md)
 - [io.swagger.client.models.QuoteDTO](docs/QuoteDTO.md)
 - [io.swagger.client.models.TokenDTO](docs/TokenDTO.md)

<a name="documentation-for-authorization"></a>
## Documentation for Authorization

<a name="ApiKeyAuth"></a>
### ApiKeyAuth


