# QuoteDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountOut** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Quoted amount out |  [optional]
**min** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Minimal amount accepted for exchange |  [optional]
**max** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | Maximal amount accepted for exchange |  [optional]
