# NetworkDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**kotlin.String**](.md) | Network name |  [optional]
**shortName** | [**kotlin.String**](.md) | Network short name |  [optional]
**addressValidation** | [**kotlin.String**](.md) | Network address validator, will return a value from https://github.com/christsim/multicoin-address-validator or regex |  [optional]
