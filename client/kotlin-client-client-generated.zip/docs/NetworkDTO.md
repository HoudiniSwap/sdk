# NetworkDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**kotlin.String**](.md) | Network name |  [optional]
**shortName** | [**kotlin.String**](.md) | Network short name |  [optional]
**memoNeeded** | [**kotlin.Boolean**](.md) | Network requires a memo/extra id field |  [optional]
**addressValidation** | [**kotlin.String**](.md) | Network address validator, will return a value from https://github.com/christsim/multicoin-address-validator or regex |  [optional]
