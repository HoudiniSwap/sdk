# Partnerexchange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**SlashcomponentsSlashparametersSlashamount**](SlashcomponentsSlashparametersSlashamount.md) |  |  [optional]
**from** | [**SlashcomponentsSlashparametersSlashfrom**](SlashcomponentsSlashparametersSlashfrom.md) |  |  [optional]
**to** | [**SlashcomponentsSlashparametersSlashto**](SlashcomponentsSlashparametersSlashto.md) |  |  [optional]
**anonymous** | [**SlashcomponentsSlashparametersSlashanonymous**](SlashcomponentsSlashparametersSlashanonymous.md) |  |  [optional]
**ip** | [**SlashcomponentsSlashparametersSlaship**](SlashcomponentsSlashparametersSlaship.md) |  |  [optional]
**userAgent** | [**SlashcomponentsSlashparametersSlashuserAgent**](SlashcomponentsSlashparametersSlashuserAgent.md) |  |  [optional]
**timezone** | [**SlashcomponentsSlashparametersSlashtimezone**](SlashcomponentsSlashparametersSlashtimezone.md) |  |  [optional]
