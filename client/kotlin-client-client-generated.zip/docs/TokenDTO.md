# TokenDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**kotlin.String**](.md) | Token ID |  [optional]
**name** | [**kotlin.String**](.md) | Token name |  [optional]
**network** | [**NetworkDTO**](NetworkDTO.md) |  |  [optional]
**symbol** | [**kotlin.String**](.md) | Token symbol |  [optional]
**color** | [**kotlin.String**](.md) | Hex color for the token |  [optional]
**keyword** | [**kotlin.String**](.md) | keywords for the token |  [optional]
**displayName** | [**kotlin.String**](.md) | Friendly display name |  [optional]
**icon** | [**kotlin.String**](.md) | Icon for the token |  [optional]
