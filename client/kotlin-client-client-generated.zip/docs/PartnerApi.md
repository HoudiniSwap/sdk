# PartnerApi

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**exchangePost**](PartnerApi.md#exchangePost) | **POST** /exchange | Create an exchange order             (partner.exchange)
[**quoteGet**](PartnerApi.md#quoteGet) | **GET** /quote | Performs a quote and returns the best price for the swap pair             (partner.quote)
[**statusGet**](PartnerApi.md#statusGet) | **GET** /status | Get the order status             (partner.status)
[**tokensGet**](PartnerApi.md#tokensGet) | **GET** /tokens | Get the list of available tokens for exchange             (partner.tokens)

<a name="exchangePost"></a>
# **exchangePost**
> InlineResponse200 exchangePost(body)

Create an exchange order             (partner.exchange)

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PartnerApi()
val body : Partnerexchange =  // Partnerexchange | Optional description in `partner.exchange` Schema
try {
    val result : InlineResponse200 = apiInstance.exchangePost(body)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PartnerApi#exchangePost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PartnerApi#exchangePost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Partnerexchange**](Partnerexchange.md)| Optional description in &#x60;partner.exchange&#x60; Schema |

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quoteGet"></a>
# **quoteGet**
> QuoteDTO quoteGet(amount, from, to, anonymous)

Performs a quote and returns the best price for the swap pair             (partner.quote)

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PartnerApi()
val amount : kotlin.String = amount_example // kotlin.String | The amount which the client is willing to transfer
val from : kotlin.String = from_example // kotlin.String | The TokenID of a currency the client will transfer
val to : kotlin.String = to_example // kotlin.String | The TokenID of a currency the client will receive
val anonymous : kotlin.Boolean = true // kotlin.Boolean | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route
try {
    val result : QuoteDTO = apiInstance.quoteGet(amount, from, to, anonymous)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PartnerApi#quoteGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PartnerApi#quoteGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **kotlin.String**| The amount which the client is willing to transfer |
 **from** | **kotlin.String**| The TokenID of a currency the client will transfer | [enum: POOF, BTC, ETH, BNB, USDT, BUSD, USDC, DAI, SOL, MATIC, ADA, XRP, XMR, USDTTRON, USDTBSC, DAIBSC, AVAXC, CRO, BUSDETH, DOGE, ETHBSC, ETHARB, USDTARB, BDX, FTM, LTC, FLOKI, SHIB, LEASH, BONE, KAVA, APE, BRISE, LINK, ATOM, ARB, APESWAP, SCRT, FIRO, FIROBSC, KNC, KNCBSC]
 **to** | **kotlin.String**| The TokenID of a currency the client will receive | [enum: POOF, BTC, ETH, BNB, USDT, BUSD, USDC, DAI, SOL, MATIC, ADA, XRP, XMR, USDTTRON, USDTBSC, DAIBSC, AVAXC, CRO, BUSDETH, DOGE, ETHBSC, ETHARB, USDTARB, BDX, FTM, LTC, FLOKI, SHIB, LEASH, BONE, KAVA, APE, BRISE, LINK, ATOM, ARB, APESWAP, SCRT, FIRO, FIROBSC, KNC, KNCBSC]
 **anonymous** | **kotlin.Boolean**| Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route |

### Return type

[**QuoteDTO**](QuoteDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="statusGet"></a>
# **statusGet**
> InlineResponse200 statusGet(id)

Get the order status             (partner.status)

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PartnerApi()
val id : kotlin.String = id_example // kotlin.String | Houdini Order ID
try {
    val result : InlineResponse200 = apiInstance.statusGet(id)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PartnerApi#statusGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PartnerApi#statusGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **kotlin.String**| Houdini Order ID |

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="tokensGet"></a>
# **tokensGet**
> kotlin.Array&lt;TokenDTO&gt; tokensGet()

Get the list of available tokens for exchange             (partner.tokens)

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*;

val apiInstance = PartnerApi()
try {
    val result : kotlin.Array<TokenDTO> = apiInstance.tokensGet()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling PartnerApi#tokensGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling PartnerApi#tokensGet")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**kotlin.Array&lt;TokenDTO&gt;**](TokenDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

