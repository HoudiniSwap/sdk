# OrderDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**houdiniId** | [**kotlin.String**](.md) | Houdini ID |  [optional]
**created** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Order created at |  [optional]
**senderAddress** | [**kotlin.String**](.md) | Address (of the deposit) to which the transfer will have to be made |  [optional]
**receiverAddress** | [**kotlin.String**](.md) | Address where the client will receive payment |  [optional]
**senderTag** | [**kotlin.String**](.md) | Deposit address tag/memo |  [optional]
**receiverTag** | [**kotlin.String**](.md) | Destination address tag/memo |  [optional]
**anonymous** | [**kotlin.Boolean**](.md) | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route |  [optional]
**expires** | [**java.time.LocalDateTime**](java.time.LocalDateTime.md) | Deposit must be made before this date/time |  [optional]
**status** | [**inline**](#StatusEnum) | Order status:          NEW: -1,         WAITING: 0,         CONFIRMING: 1,         EXCHANGING: 2,         ANONYMIZING: 3,         FINISHED: 4,         EXPIRED: 5,         FAILED: 6,         REFUNDED: 7 |  [optional]
**inAmount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The amount that the client specified when creating the exchange |  [optional]
**inSymbol** | [**inline**](#InSymbolEnum) | The TokenID of a currency the client will transfer |  [optional]
**outAmount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) | The amount that will be returned by the exchange to the specified receiverAddress |  [optional]
**outSymbol** | [**inline**](#OutSymbolEnum) | The TokenID of a currency the client will receive |  [optional]

<a name="StatusEnum"></a>
## Enum: status
Name | Value
---- | -----
status | -1, 0, 1, 2, 3, 4, 5, 6, 7

<a name="InSymbolEnum"></a>
## Enum: inSymbol
Name | Value
---- | -----
inSymbol | POOF, BTC, ETH, BNB, USDT, BUSD, USDC, DAI, SOL, MATIC, ADA, XRP, XMR, USDTTRON, USDTBSC, DAIBSC, AVAXC, CRO, BUSDETH, DOGE, ETHBSC, ETHARB, USDTARB, BDX, FTM, LTC, FLOKI, SHIB, LEASH, BONE, KAVA, APE, BRISE, LINK, ATOM, ARB, APESWAP, SCRT, FIRO, FIROBSC, KNC, KNCBSC, ARC

<a name="OutSymbolEnum"></a>
## Enum: outSymbol
Name | Value
---- | -----
outSymbol | POOF, BTC, ETH, BNB, USDT, BUSD, USDC, DAI, SOL, MATIC, ADA, XRP, XMR, USDTTRON, USDTBSC, DAIBSC, AVAXC, CRO, BUSDETH, DOGE, ETHBSC, ETHARB, USDTARB, BDX, FTM, LTC, FLOKI, SHIB, LEASH, BONE, KAVA, APE, BRISE, LINK, ATOM, ARB, APESWAP, SCRT, FIRO, FIROBSC, KNC, KNCBSC, ARC
