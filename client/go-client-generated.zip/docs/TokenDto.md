# TokenDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Token ID | [optional] [default to null]
**Name** | **string** | Token name | [optional] [default to null]
**Network** | [***NetworkDto**](NetworkDTO.md) |  | [optional] [default to null]
**Symbol** | **string** | Token symbol | [optional] [default to null]
**Color** | **string** | Hex color for the token | [optional] [default to null]
**Keyword** | **string** | keywords for the token | [optional] [default to null]
**DisplayName** | **string** | Friendly display name | [optional] [default to null]
**Icon** | **string** | Icon for the token | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

