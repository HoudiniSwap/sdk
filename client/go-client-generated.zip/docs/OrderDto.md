# OrderDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HoudiniId** | **string** | Houdini ID | [optional] [default to null]
**Created** | [***DateTime**](date-time.md) | Order created at | [optional] [default to null]
**SenderAddress** | **string** | Address (of the deposit) to which the transfer will have to be made | [optional] [default to null]
**ReceiverAddress** | **string** | Address where the client will receive payment | [optional] [default to null]
**SenderTag** | **string** | Deposit address tag/memo | [optional] [default to null]
**ReceiverTag** | **string** | Destination address tag/memo | [optional] [default to null]
**Anonymous** | **bool** | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route | [optional] [default to null]
**Expires** | [***DateTime**](date-time.md) | Deposit must be made before this date/time | [optional] [default to null]
**Status** | **float64** | Order status:          NEW: -1,         WAITING: 0,         CONFIRMING: 1,         EXCHANGING: 2,         ANONYMIZING: 3,         FINISHED: 4,         EXPIRED: 5,         FAILED: 6,         REFUNDED: 7 | [optional] [default to null]
**InAmount** | **float64** | The amount that the client specified when creating the exchange | [optional] [default to null]
**InSymbol** | **string** | The TokenID of a currency the client will transfer | [optional] [default to null]
**OutAmount** | **float64** | The amount that will be returned by the exchange to the specified receiverAddress | [optional] [default to null]
**OutSymbol** | **string** | The TokenID of a currency the client will receive | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

