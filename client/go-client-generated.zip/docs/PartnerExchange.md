# PartnerExchange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | [***Componentsparametersamount**](#/components/parameters/amount.md) |  | [optional] [default to null]
**From** | [***Componentsparametersfrom**](#/components/parameters/from.md) |  | [optional] [default to null]
**To** | [***Componentsparametersto**](#/components/parameters/to.md) |  | [optional] [default to null]
**Anonymous** | [***Componentsparametersanonymous**](#/components/parameters/anonymous.md) |  | [optional] [default to null]
**Ip** | [***Componentsparametersip**](#/components/parameters/ip.md) |  | [optional] [default to null]
**UserAgent** | [***ComponentsparametersuserAgent**](#/components/parameters/userAgent.md) |  | [optional] [default to null]
**Timezone** | [***Componentsparameterstimezone**](#/components/parameters/timezone.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

