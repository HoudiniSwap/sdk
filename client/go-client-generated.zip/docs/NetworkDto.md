# NetworkDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Network name | [optional] [default to null]
**ShortName** | **string** | Network short name | [optional] [default to null]
**MemoNeeded** | **bool** | Network requires a memo/extra id field | [optional] [default to null]
**AddressValidation** | **string** | Network address validator, will return a value from https://github.com/christsim/multicoin-address-validator or regex | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

