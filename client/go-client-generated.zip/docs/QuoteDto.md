# QuoteDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AmountOut** | **float64** | Quoted amount out | [optional] [default to null]
**Min** | **float64** | Minimal amount accepted for exchange | [optional] [default to null]
**Max** | **float64** | Maximal amount accepted for exchange | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

