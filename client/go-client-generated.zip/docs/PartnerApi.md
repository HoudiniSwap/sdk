# {{classname}}

All URIs are relative to */*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ExchangePost**](PartnerApi.md#ExchangePost) | **Post** /exchange | Create an exchange order             (partner.exchange)
[**QuoteGet**](PartnerApi.md#QuoteGet) | **Get** /quote | Performs a quote and returns the best price for the swap pair             (partner.quote)
[**StatusGet**](PartnerApi.md#StatusGet) | **Get** /status | Get the order status             (partner.status)
[**TokensGet**](PartnerApi.md#TokensGet) | **Get** /tokens | Get the list of available tokens for exchange             (partner.tokens)

# **ExchangePost**
> InlineResponse200 ExchangePost(ctx, body)
Create an exchange order             (partner.exchange)

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**PartnerExchange**](PartnerExchange.md)| Optional description in &#x60;partner.exchange&#x60; Schema | 

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **QuoteGet**
> QuoteDto QuoteGet(ctx, amount, from, to, anonymous)
Performs a quote and returns the best price for the swap pair             (partner.quote)

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **amount** | **string**| The amount which the client is willing to transfer | 
  **from** | **string**| The TokenID of a currency the client will transfer | 
  **to** | **string**| The TokenID of a currency the client will receive | 
  **anonymous** | **bool**| Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route | 

### Return type

[**QuoteDto**](QuoteDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **StatusGet**
> InlineResponse200 StatusGet(ctx, id)
Get the order status             (partner.status)

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **id** | **string**| Houdini Order ID | 

### Return type

[**InlineResponse200**](inline_response_200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **TokensGet**
> []TokenDto TokensGet(ctx, )
Get the list of available tokens for exchange             (partner.tokens)

### Required Parameters
This endpoint does not need any parameter.

### Return type

[**[]TokenDto**](TokenDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

