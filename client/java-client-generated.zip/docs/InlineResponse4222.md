# InlineResponse4222

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
