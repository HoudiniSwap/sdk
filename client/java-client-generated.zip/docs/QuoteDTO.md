# QuoteDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amountOut** | [**BigDecimal**](BigDecimal.md) | Quoted amount out |  [optional]
**min** | [**BigDecimal**](BigDecimal.md) | Minimal amount accepted for exchange |  [optional]
**max** | [**BigDecimal**](BigDecimal.md) | Maximal amount accepted for exchange |  [optional]
