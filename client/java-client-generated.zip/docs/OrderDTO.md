# OrderDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**houdiniId** | **String** | Houdini ID |  [optional]
**created** | [**OffsetDateTime**](DateTime.md) | Order created at |  [optional]
**senderAddress** | **String** | Address (of the deposit) to which the transfer will have to be made |  [optional]
**receiverAddress** | **String** | Address where the client will receive payment |  [optional]
**senderTag** | **String** | Deposit address tag/memo |  [optional]
**receiverTag** | **String** | Destination address tag/memo |  [optional]
**anonymous** | **Boolean** | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route |  [optional]
**expires** | [**OffsetDateTime**](DateTime.md) | Deposit must be made before this date/time |  [optional]
**status** | [**StatusEnum**](#StatusEnum) | Order status:          NEW: -1,         WAITING: 0,         CONFIRMING: 1,         EXCHANGING: 2,         ANONYMIZING: 3,         FINISHED: 4,         EXPIRED: 5,         FAILED: 6,         REFUNDED: 7 |  [optional]
**inAmount** | [**BigDecimal**](BigDecimal.md) | The amount that the client specified when creating the exchange |  [optional]
**inSymbol** | [**InSymbolEnum**](#InSymbolEnum) | The TokenID of a currency the client will transfer |  [optional]
**outAmount** | [**BigDecimal**](BigDecimal.md) | The amount that will be returned by the exchange to the specified receiverAddress |  [optional]
**outSymbol** | [**OutSymbolEnum**](#OutSymbolEnum) | The TokenID of a currency the client will receive |  [optional]

<a name="StatusEnum"></a>
## Enum: StatusEnum
Name | Value
---- | -----
NUMBER_MINUS_1 | new BigDecimal(-1)
NUMBER_0 | new BigDecimal(0)
NUMBER_1 | new BigDecimal(1)
NUMBER_2 | new BigDecimal(2)
NUMBER_3 | new BigDecimal(3)
NUMBER_4 | new BigDecimal(4)
NUMBER_5 | new BigDecimal(5)
NUMBER_6 | new BigDecimal(6)
NUMBER_7 | new BigDecimal(7)

<a name="InSymbolEnum"></a>
## Enum: InSymbolEnum
Name | Value
---- | -----
POOF | &quot;POOF&quot;
BTC | &quot;BTC&quot;
ETH | &quot;ETH&quot;
BNB | &quot;BNB&quot;
USDT | &quot;USDT&quot;
BUSD | &quot;BUSD&quot;
USDC | &quot;USDC&quot;
DAI | &quot;DAI&quot;
SOL | &quot;SOL&quot;
MATIC | &quot;MATIC&quot;
ADA | &quot;ADA&quot;
XRP | &quot;XRP&quot;
XMR | &quot;XMR&quot;
USDTTRON | &quot;USDTTRON&quot;
USDTBSC | &quot;USDTBSC&quot;
DAIBSC | &quot;DAIBSC&quot;
AVAXC | &quot;AVAXC&quot;
CRO | &quot;CRO&quot;
BUSDETH | &quot;BUSDETH&quot;
DOGE | &quot;DOGE&quot;
ETHBSC | &quot;ETHBSC&quot;
ETHARB | &quot;ETHARB&quot;
USDTARB | &quot;USDTARB&quot;
BDX | &quot;BDX&quot;
FTM | &quot;FTM&quot;
LTC | &quot;LTC&quot;
FLOKI | &quot;FLOKI&quot;
SHIB | &quot;SHIB&quot;
LEASH | &quot;LEASH&quot;
BONE | &quot;BONE&quot;
KAVA | &quot;KAVA&quot;
APE | &quot;APE&quot;
BRISE | &quot;BRISE&quot;
LINK | &quot;LINK&quot;
ATOM | &quot;ATOM&quot;
ARB | &quot;ARB&quot;
APESWAP | &quot;APESWAP&quot;
SCRT | &quot;SCRT&quot;
FIRO | &quot;FIRO&quot;
FIROBSC | &quot;FIROBSC&quot;
KNC | &quot;KNC&quot;
KNCBSC | &quot;KNCBSC&quot;
ARC | &quot;ARC&quot;

<a name="OutSymbolEnum"></a>
## Enum: OutSymbolEnum
Name | Value
---- | -----
POOF | &quot;POOF&quot;
BTC | &quot;BTC&quot;
ETH | &quot;ETH&quot;
BNB | &quot;BNB&quot;
USDT | &quot;USDT&quot;
BUSD | &quot;BUSD&quot;
USDC | &quot;USDC&quot;
DAI | &quot;DAI&quot;
SOL | &quot;SOL&quot;
MATIC | &quot;MATIC&quot;
ADA | &quot;ADA&quot;
XRP | &quot;XRP&quot;
XMR | &quot;XMR&quot;
USDTTRON | &quot;USDTTRON&quot;
USDTBSC | &quot;USDTBSC&quot;
DAIBSC | &quot;DAIBSC&quot;
AVAXC | &quot;AVAXC&quot;
CRO | &quot;CRO&quot;
BUSDETH | &quot;BUSDETH&quot;
DOGE | &quot;DOGE&quot;
ETHBSC | &quot;ETHBSC&quot;
ETHARB | &quot;ETHARB&quot;
USDTARB | &quot;USDTARB&quot;
BDX | &quot;BDX&quot;
FTM | &quot;FTM&quot;
LTC | &quot;LTC&quot;
FLOKI | &quot;FLOKI&quot;
SHIB | &quot;SHIB&quot;
LEASH | &quot;LEASH&quot;
BONE | &quot;BONE&quot;
KAVA | &quot;KAVA&quot;
APE | &quot;APE&quot;
BRISE | &quot;BRISE&quot;
LINK | &quot;LINK&quot;
ATOM | &quot;ATOM&quot;
ARB | &quot;ARB&quot;
APESWAP | &quot;APESWAP&quot;
SCRT | &quot;SCRT&quot;
FIRO | &quot;FIRO&quot;
FIROBSC | &quot;FIROBSC&quot;
KNC | &quot;KNC&quot;
KNCBSC | &quot;KNCBSC&quot;
ARC | &quot;ARC&quot;
