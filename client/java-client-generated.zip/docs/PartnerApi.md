# PartnerApi

All URIs are relative to *https://api-partner.houdiniswap.com/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**exchangePost**](PartnerApi.md#exchangePost) | **POST** /exchange | Create an exchange order             (partner.exchange)
[**quoteGet**](PartnerApi.md#quoteGet) | **GET** /quote | Performs a quote and returns the best price for the swap pair             (partner.quote)
[**statusGet**](PartnerApi.md#statusGet) | **GET** /status | Get the order status             (partner.status)
[**tokensGet**](PartnerApi.md#tokensGet) | **GET** /tokens | Get the list of available tokens for exchange             (partner.tokens)

<a name="exchangePost"></a>
# **exchangePost**
> InlineResponse200 exchangePost(body)

Create an exchange order             (partner.exchange)

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PartnerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: ApiKeyAuth
ApiKeyAuth ApiKeyAuth = (ApiKeyAuth) defaultClient.getAuthentication("ApiKeyAuth");
ApiKeyAuth.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//ApiKeyAuth.setApiKeyPrefix("Token");

PartnerApi apiInstance = new PartnerApi();
PartnerExchange body = new PartnerExchange(); // PartnerExchange | Optional description in `partner.exchange` Schema
try {
    InlineResponse200 result = apiInstance.exchangePost(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PartnerApi#exchangePost");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PartnerExchange**](PartnerExchange.md)| Optional description in &#x60;partner.exchange&#x60; Schema |

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="quoteGet"></a>
# **quoteGet**
> QuoteDTO quoteGet(amount, from, to, anonymous)

Performs a quote and returns the best price for the swap pair             (partner.quote)

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PartnerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: ApiKeyAuth
ApiKeyAuth ApiKeyAuth = (ApiKeyAuth) defaultClient.getAuthentication("ApiKeyAuth");
ApiKeyAuth.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//ApiKeyAuth.setApiKeyPrefix("Token");

PartnerApi apiInstance = new PartnerApi();
String amount = "amount_example"; // String | The amount which the client is willing to transfer
String from = "from_example"; // String | The TokenID of a currency the client will transfer
String to = "to_example"; // String | The TokenID of a currency the client will receive
Boolean anonymous = true; // Boolean | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route
try {
    QuoteDTO result = apiInstance.quoteGet(amount, from, to, anonymous);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PartnerApi#quoteGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **String**| The amount which the client is willing to transfer |
 **from** | **String**| The TokenID of a currency the client will transfer | [enum: POOF, BTC, ETH, BNB, USDT, BUSD, USDC, DAI, SOL, MATIC, ADA, XRP, XMR, USDTTRON, USDTBSC, DAIBSC, AVAXC, CRO, BUSDETH, DOGE, ETHBSC, ETHARB, USDTARB, BDX, FTM, LTC, FLOKI, SHIB, LEASH, BONE, KAVA, APE, BRISE, LINK, ATOM, ARB, APESWAP, SCRT, FIRO, FIROBSC, KNC, KNCBSC, ARC]
 **to** | **String**| The TokenID of a currency the client will receive | [enum: POOF, BTC, ETH, BNB, USDT, BUSD, USDC, DAI, SOL, MATIC, ADA, XRP, XMR, USDTTRON, USDTBSC, DAIBSC, AVAXC, CRO, BUSDETH, DOGE, ETHBSC, ETHARB, USDTARB, BDX, FTM, LTC, FLOKI, SHIB, LEASH, BONE, KAVA, APE, BRISE, LINK, ATOM, ARB, APESWAP, SCRT, FIRO, FIROBSC, KNC, KNCBSC, ARC]
 **anonymous** | **Boolean**| Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route |

### Return type

[**QuoteDTO**](QuoteDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="statusGet"></a>
# **statusGet**
> InlineResponse200 statusGet(id)

Get the order status             (partner.status)

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PartnerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: ApiKeyAuth
ApiKeyAuth ApiKeyAuth = (ApiKeyAuth) defaultClient.getAuthentication("ApiKeyAuth");
ApiKeyAuth.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//ApiKeyAuth.setApiKeyPrefix("Token");

PartnerApi apiInstance = new PartnerApi();
String id = "id_example"; // String | Houdini Order ID
try {
    InlineResponse200 result = apiInstance.statusGet(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PartnerApi#statusGet");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **String**| Houdini Order ID |

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="tokensGet"></a>
# **tokensGet**
> List&lt;TokenDTO&gt; tokensGet()

Get the list of available tokens for exchange             (partner.tokens)

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.PartnerApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure API key authorization: ApiKeyAuth
ApiKeyAuth ApiKeyAuth = (ApiKeyAuth) defaultClient.getAuthentication("ApiKeyAuth");
ApiKeyAuth.setApiKey("YOUR API KEY");
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//ApiKeyAuth.setApiKeyPrefix("Token");

PartnerApi apiInstance = new PartnerApi();
try {
    List<TokenDTO> result = apiInstance.tokensGet();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling PartnerApi#tokensGet");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;TokenDTO&gt;**](TokenDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

