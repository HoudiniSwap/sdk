# InlineResponse4221

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
