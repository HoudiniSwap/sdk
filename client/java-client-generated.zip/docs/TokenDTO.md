# TokenDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** | Token ID |  [optional]
**name** | **String** | Token name |  [optional]
**network** | [**NetworkDTO**](NetworkDTO.md) |  |  [optional]
**symbol** | **String** | Token symbol |  [optional]
**color** | **String** | Hex color for the token |  [optional]
**keyword** | **String** | keywords for the token |  [optional]
**displayName** | **String** | Friendly display name |  [optional]
**icon** | **String** | Icon for the token |  [optional]
