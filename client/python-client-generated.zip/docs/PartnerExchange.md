# PartnerExchange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**amount** | [**Componentsparametersamount**](Componentsparametersamount.md) |  | [optional] 
**_from** | [**Componentsparametersfrom**](Componentsparametersfrom.md) |  | [optional] 
**to** | [**Componentsparametersto**](Componentsparametersto.md) |  | [optional] 
**receiver_tag** | [**ComponentsparametersreceiverTag**](ComponentsparametersreceiverTag.md) |  | [optional] 
**anonymous** | [**Componentsparametersanonymous**](Componentsparametersanonymous.md) |  | [optional] 
**ip** | [**Componentsparametersip**](Componentsparametersip.md) |  | [optional] 
**user_agent** | [**ComponentsparametersuserAgent**](ComponentsparametersuserAgent.md) |  | [optional] 
**timezone** | [**Componentsparameterstimezone**](Componentsparameterstimezone.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

