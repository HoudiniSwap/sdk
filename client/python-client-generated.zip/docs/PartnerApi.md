# swagger_client.PartnerApi

All URIs are relative to *https://api-partner.houdiniswap.com/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**exchange_post**](PartnerApi.md#exchange_post) | **POST** /exchange | Create an exchange order             (partner.exchange)
[**quote_get**](PartnerApi.md#quote_get) | **GET** /quote | Performs a quote and returns the best price for the swap pair             (partner.quote)
[**status_get**](PartnerApi.md#status_get) | **GET** /status | Get the order status             (partner.status)
[**tokens_get**](PartnerApi.md#tokens_get) | **GET** /tokens | Get the list of available tokens for exchange             (partner.tokens)

# **exchange_post**
> InlineResponse200 exchange_post(body)

Create an exchange order             (partner.exchange)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.PartnerApi(swagger_client.ApiClient(configuration))
body = swagger_client.PartnerExchange() # PartnerExchange | Optional description in `partner.exchange` Schema

try:
    # Create an exchange order             (partner.exchange)
    api_response = api_instance.exchange_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PartnerApi->exchange_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**PartnerExchange**](PartnerExchange.md)| Optional description in &#x60;partner.exchange&#x60; Schema | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **quote_get**
> QuoteDTO quote_get(amount, _from, to, anonymous)

Performs a quote and returns the best price for the swap pair             (partner.quote)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.PartnerApi(swagger_client.ApiClient(configuration))
amount = 'amount_example' # str | The amount which the client is willing to transfer
_from = '_from_example' # str | The TokenID of a currency the client will transfer
to = 'to_example' # str | The TokenID of a currency the client will receive
anonymous = true # bool | Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route

try:
    # Performs a quote and returns the best price for the swap pair             (partner.quote)
    api_response = api_instance.quote_get(amount, _from, to, anonymous)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PartnerApi->quote_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **amount** | **str**| The amount which the client is willing to transfer | 
 **_from** | **str**| The TokenID of a currency the client will transfer | 
 **to** | **str**| The TokenID of a currency the client will receive | 
 **anonymous** | **bool**| Anonymous / Non-anonymous flow. For Anonymous, it will go through a XMR route | 

### Return type

[**QuoteDTO**](QuoteDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **status_get**
> InlineResponse200 status_get(id)

Get the order status             (partner.status)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.PartnerApi(swagger_client.ApiClient(configuration))
id = 'id_example' # str | Houdini Order ID

try:
    # Get the order status             (partner.status)
    api_response = api_instance.status_get(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PartnerApi->status_get: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| Houdini Order ID | 

### Return type

[**InlineResponse200**](InlineResponse200.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **tokens_get**
> list[TokenDTO] tokens_get()

Get the list of available tokens for exchange             (partner.tokens)

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# Configure API key authorization: ApiKeyAuth
configuration = swagger_client.Configuration()
configuration.api_key['Authorization'] = 'YOUR_API_KEY'
# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['Authorization'] = 'Bearer'

# create an instance of the API class
api_instance = swagger_client.PartnerApi(swagger_client.ApiClient(configuration))

try:
    # Get the list of available tokens for exchange             (partner.tokens)
    api_response = api_instance.tokens_get()
    pprint(api_response)
except ApiException as e:
    print("Exception when calling PartnerApi->tokens_get: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**list[TokenDTO]**](TokenDTO.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

