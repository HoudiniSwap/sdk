# TokenDTO

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Token ID | [optional] 
**name** | **str** | Token name | [optional] 
**network** | [**NetworkDTO**](NetworkDTO.md) |  | [optional] 
**symbol** | **str** | Token symbol | [optional] 
**color** | **str** | Hex color for the token | [optional] 
**keyword** | **str** | keywords for the token | [optional] 
**display_name** | **str** | Friendly display name | [optional] 
**icon** | **str** | Icon for the token | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

